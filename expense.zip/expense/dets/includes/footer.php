<div class="col-sm-12">
				<p class="back-link">Daily Expense Tracker <a href="https://phpgurukul.com">phpgurukul</a></p>
			</div>